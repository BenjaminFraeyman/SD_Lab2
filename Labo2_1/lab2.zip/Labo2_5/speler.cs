﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2_5
{
    class Speler
    {
        public List<Kaart> hand = new List<Kaart>();
        private string naam1;
        public Speler(string naam) { naam = naam1; }
        public string spelernaam { get; private set; }
        Random random = new Random();
        public List<Kaart> rondes = new List<Kaart>();

        public void Geefkaart(Kaart temp)
        {
            hand.Add(temp);
        }
        
        public void displayhand()
        {
            foreach (object o in hand)
            {
                Console.Write(o);
            }
        }

        public void Returnkaart()
        {
            int rand = random.Next(hand.Count);
            Kaart tempp = hand[rand];
            Console.Write(tempp);
            rondes.Add(tempp);
            hand.RemoveAt(rand);
        }
    }}
