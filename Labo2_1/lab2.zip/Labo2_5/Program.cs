﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Kaarten deck = new Kaarten();
            deck.Generate();
            deck.Verdeel();
            deck.Ronde();
            deck.Eval1();
            deck.Eval2();
            Console.WriteLine();
            Console.WriteLine("BENODIGDE TIJD: 8 uur (volledig hermaakt na het labo)");
            Console.ReadLine();
        }
    }
}
