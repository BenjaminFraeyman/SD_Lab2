﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2_5
{
    class Kaarten
    {
        Random random = new Random();
        // lijst voor de plaatjes
        public string[] Beeld = new string[] { "klaver", "ruiten", "schoppen", "harten" };
        //aanmaak van de lijst waar je de kaarten insteekt
        public List<Kaart> deck = new List<Kaart>();
        //aanmaak van de lijst waar je de spelers insteekt
        public List<Speler> spelers = new List<Speler>();
        //opslag van de scores per speler
        public int scores1 = 0;
        public int scores2 = 0;
        public int scores3 = 0;
        public int scores0 = 0;

        public void Generate(){
            int value = 0;
            // aanmaken van je spel kaarten
            for (int waarde = 0; waarde < 13; waarde++)
            {
                for (int i = 0; i < Beeld.Length; i++)
                {
                    value++;
                    string beeld = Beeld[i];
                    Kaart kaart = new Kaart(beeld, waarde, value);
                    deck.Add(kaart);
                    Console.Write(kaart + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
            //je spelers toevoegen aan de lijst
            spelers.Add(new Speler("speler1"));
            spelers.Add(new Speler("speler2"));
            spelers.Add(new Speler("speler3"));
            spelers.Add(new Speler("speler4"));}

        public void Verdeel(){
            // uitdelen van de kaarten
            for (int kaart = 0; kaart < 13; kaart++)
            {
                for (int j = 0; j < 4; j++)
                {
                    // willekeurig kaart nemen, geven aan de speler, dan verwijderen uit je spel kaarten
                    int rand = random.Next(deck.Count);
                    Kaart temp = deck[rand];
                    spelers[j].Geefkaart(temp);
                    deck.RemoveAt(rand);
                }
            }
            for (int j = 0; j < 4; j++)
            {
                // hand per speler uitprinten
                Console.WriteLine("speler{0}:", j);
                spelers[j].displayhand();
                Console.WriteLine();
            }}

        public void Ronde(){
            Console.WriteLine();
            Console.WriteLine();
            for (int kaart = 0; kaart < 13; kaart++)
            {
                Console.WriteLine("Ronde {0}", kaart);
                for (int j = 0; j < 4; j++)
                {
                    //willekeurig een kaart uit de hand van een speler nemen en die op console plaatsen
                    Console.Write(" speler{0}: ", j);
                    spelers[j].Returnkaart();
                }
                Console.WriteLine();
            }}

        public void Eval1(){
            Console.WriteLine();
            Console.WriteLine("Evaluatiemethode 1");
            for (int ronde = 0; ronde < 13; ronde++)
            {
                int[] waardes = new int[4];
                // oproepen van de kaartwaarde per ronde per speler
                waardes[0] = spelers[0].rondes[ronde].val;
                waardes[1] = spelers[1].rondes[ronde].val;
                waardes[2] = spelers[2].rondes[ronde].val;
                waardes[3] = spelers[3].rondes[ronde].val;
                // kijken welke speler de maximum waarde heeft
                if (waardes[0] == waardes.Max()){
                    Console.WriteLine("Speler0 +1 (ronde{0})", ronde);
                    scores0++;}
                if (waardes[1] == waardes.Max()){
                    Console.WriteLine("Speler1 +1 (ronde{0})", ronde);
                    scores1++;}
                if (waardes[2] == waardes.Max()){
                    Console.WriteLine("Speler2 +1 (ronde{0})", ronde);
                    scores2++;}
                if (waardes[3] == waardes.Max()){
                    Console.WriteLine("Speler3 +1 (ronde{0})", ronde);
                    scores3++;}
            }
            Console.WriteLine();
            Console.WriteLine("Speler0 scoort: {0}", scores0);
            Console.WriteLine("Speler1 scoort: {0}", scores1);
            Console.WriteLine("Speler2 scoort: {0}", scores2);
            Console.WriteLine("Speler3 scoort: {0}", scores3);}

        public void Eval2(){
            Console.WriteLine();
            Console.WriteLine("Evaluatiemethode 2");
            for (int ronde = 0; ronde < 13; ronde++)
            {
                Console.WriteLine();
                int[] waardes = new int[4];
                waardes[0] = spelers[0].rondes[ronde].val;
                waardes[1] = spelers[1].rondes[ronde].val;
                waardes[2] = spelers[2].rondes[ronde].val;
                waardes[3] = spelers[3].rondes[ronde].val;
                if (waardes[0] == waardes.Max()){
                    Console.WriteLine("Speler0 +2 (ronde{0})", ronde);
                    scores0 = scores0 + 2;}
                if (waardes[1] == waardes.Max()){
                    Console.WriteLine("Speler1 +2 (ronde{0})", ronde);
                    scores1 = scores1 + 2;}
                if (waardes[2] == waardes.Max()){
                    Console.WriteLine("Speler2 +2 (ronde{0})", ronde);
                    scores2 = scores2 + 2;}
                if (waardes[3] == waardes.Max()){
                    Console.WriteLine("Speler3 +2 (ronde{0})", ronde);
                    scores3 = scores3 + 2;}
                // kijken welke speler de minimum score heeft
                if (waardes[0] == waardes.Min()){
                    Console.WriteLine("Speler0 -2 (ronde{0})", ronde);
                    scores0 = scores0 - 2;}
                if (waardes[1] == waardes.Min()){
                    Console.WriteLine("Speler1 -2 (ronde{0})", ronde);
                    scores1 = scores1 - 2;}
                if (waardes[2] == waardes.Min()){
                    Console.WriteLine("Speler2 -2 (ronde{0})", ronde);
                    scores2 = scores2 - 2;}
                if (waardes[3] == waardes.Min()){
                    Console.WriteLine("Speler3 -2 (ronde{0})", ronde);
                    scores3 = scores3 - 2;}
                //kijken welke speler de 2de maximum score heeft
                if (waardes[0] == Secmax(waardes)){
                    Console.WriteLine("Speler0 +1 (ronde{0})", ronde);
                    scores0 = scores0 + 1;}
                if (waardes[1] == Secmax(waardes)){
                    Console.WriteLine("Speler1 +1 (ronde{0})", ronde);
                    scores1 = scores1 + 1;}
                if (waardes[2] == Secmax(waardes)){
                    Console.WriteLine("Speler2 +1 (ronde{0})", ronde);
                    scores2 = scores2 + 1;}
                if (waardes[3] == Secmax(waardes)){
                    Console.WriteLine("Speler3 +1 (ronde{0})", ronde);
                    scores3 = scores3 + 1;}
                //kijken welke speler de 2de minimum score heeft
                if (waardes[0] == Secmin(waardes)){
                    Console.WriteLine("Speler0 -1 (ronde{0})", ronde);
                    scores0 = scores0 - 1;}
                if (waardes[1] == Secmin(waardes)){
                    Console.WriteLine("Speler1 -1 (ronde{0})", ronde);
                    scores1 = scores1 - 1;}
                if (waardes[2] == Secmin(waardes)){
                    Console.WriteLine("Speler2 -1 (ronde{0})", ronde);
                    scores2 = scores2 - 1;}
                if (waardes[3] == Secmin(waardes)){
                    Console.WriteLine("Speler3 -1 (ronde{0})", ronde);
                    scores3 = scores3 - 1;}
            }
            Console.WriteLine();
            Console.WriteLine("Speler0 scoort: {0}", scores0);
            Console.WriteLine("Speler1 scoort: {0}", scores1);
            Console.WriteLine("Speler2 scoort: {0}", scores2);
            Console.WriteLine("Speler3 scoort: {0}", scores3);}

        private int Secmax(int[] waardes){
            // bepalen van het 2de maximum
            int maxVal = 0;
            int secondMax = 0;
            for (int i = 0; i < waardes.Length; i++)
            {
                if (waardes[i] > maxVal){
                    secondMax = maxVal;
                    maxVal = waardes[i];}
                else if (waardes[i] > secondMax){
                    secondMax = waardes[i];}
            }
            return secondMax;}

        private int Secmin(int[] waardes){
            // bepalen van het 2de minimum
            int minVal = 1000;
            int secondMin = 1000;
            for (int i = 0; i < waardes.Length; i++)
            {
                if (waardes[i] < minVal){
                    secondMin = minVal;
                    minVal = waardes[i];}
                else if (waardes[i] < secondMin){
                    secondMin = waardes[i];}
            }
            return secondMin;}
    } }
