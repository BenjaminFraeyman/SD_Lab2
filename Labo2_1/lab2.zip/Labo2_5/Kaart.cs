﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2_5
{
    class Kaart
    {
        public string be { get; private set; }
        public int wa { get; private set; }
        public int val { get; private set; }
// aanmaak van een kaartje
        public Kaart(string beeld, int waarde, int value)
        {
            be = beeld;
            wa = waarde;
            val = value;
        }

        public override string ToString()
        {
            return be + " " + wa + " ";
        }
    }
}
