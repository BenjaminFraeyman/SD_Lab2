﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2_3_Complexegetallen
{
    class Program
    {
        // (klasses waar getal ingeplaatst word staat in getal.cs bestand)

        static void Main(string[] args)
        {
            Console.WriteLine("BENODIGDE TIJD: tussen 5 en 6 uur");
            Console.WriteLine("veel moeite gehad met opstellen van de klassen");

            Console.WriteLine("Geef getal1 in (gesplitst met ; (vb. 2;3,5))"); // input
            var getal1 = Console.ReadLine();
            var getalLijst1 = getal1.Split(';'); // om de getallen van elkaar te onderscheiden
            double deel11 = Convert.ToDouble(getalLijst1[0]); // real deel
            double deel12 = Convert.ToDouble(getalLijst1[1]); // complex deel
            Complex number1 = new Complex(deel11, deel12); // opslag in nieuw complex getal

            Console.WriteLine("Geef getal2 in (gesplitst met ; (vb. 2;3,5))");
            var getal2 = Console.ReadLine();
            var getalLijst2 = getal2.Split(';');
            double deel21 = Convert.ToDouble(getalLijst2[0]);
            double deel22 = Convert.ToDouble(getalLijst2[1]);
            Complex number2 = new Complex(deel21, deel22);

            Console.WriteLine("De getallen zijn");
            Console.WriteLine(number1);
            Console.WriteLine(number2);

            // oproep som
            Console.WriteLine("De som is");
            number1 = Complex.Add(number1, number2);
            Console.WriteLine(number1);

            // oproep aftrekking
            Console.WriteLine("De aftrekking is");
            number1 = Complex.Min(number1, number2);
            Console.WriteLine(number1);

            // oproep product
            Console.WriteLine("Het product is");
            number1 = Complex.Maal(number1, number2);
            Console.WriteLine(number1);

            // oproep deling
            Console.WriteLine("De deling is");
            number1 = Complex.Delen(number1, number2);
            Console.WriteLine(number1);

            Console.ReadLine();
        }
    }
}