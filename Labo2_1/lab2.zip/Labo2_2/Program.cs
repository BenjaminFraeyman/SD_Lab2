﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2_2
{
    class Invoer
    {
        static void Main(string[] args)
        {
            Console.WriteLine("BENODIGDE TIJD: 20 minuten");

            Console.WriteLine("Getal?"); // input
            string getal = Console.ReadLine();

            int geheel = Geheel(getal); 
            double komma = Komma(getal);
            Console.ReadLine();

        }
        static int Geheel(string getal) // indien input geheel getal is
        {
            int geheel;
            bool geheelgetal = int.TryParse(getal, out geheel); // check of het een geheel getal is
            if (geheelgetal)
            {
                Console.WriteLine(geheel);
                return geheel;
            }
            else
            {
                Console.WriteLine(0);
                return 0;
            }
        }

        static double Komma(string getal) // indien input kommagetal is
        {
            double komma;
            bool kommagetal = double.TryParse(getal, out komma);// check of het een kommagetal is
            if (kommagetal)
            {
                Console.WriteLine(komma);
                return komma;
            }
            else
            {
                Console.WriteLine(0);
                return 0;
            }

        }
    }
}

// benodigde tijd
// 20 minuten
