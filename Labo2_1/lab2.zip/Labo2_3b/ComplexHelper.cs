﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2_3b
{
    class ComplexHelper
    {
        public static Complex Add(Complex number1, Complex number2)
        {
            double realsom = number1.Real + number2.Real;
            double complexsom = number1.Imaginary + number2.Imaginary;
            Complex number = new Complex(realsom, complexsom);
            return number;
        }

        public static Complex Min(Complex number1, Complex number2)
        {
            double realmin = number1.Real - number2.Real;
            double complexmin = number1.Imaginary - number2.Imaginary;
            Complex number = new Complex(realmin, complexmin);
            return number;
        }

        public static Complex Maal(Complex number1, Complex number2)
        {
            double part1 = number1.Real * number2.Real;
            double part2 = number1.Imaginary * number2.Imaginary;
            double part3 = part1 - part2;

            double part4 = number1.Imaginary * number2.Real;
            double part5 = number1.Real * number2.Imaginary;
            double part6 = part4 + part5;

            Complex number = new Complex(part3, part6);
            return number;
        }

        public static Complex Delen(Complex number1, Complex number2)
        {
            double part1 = number1.Real * number2.Real;
            double part2 = number1.Imaginary * number2.Imaginary;
            double part3 = part1 + part2;

            double part4 = number2.Real * number2.Real;

            double part5 = part3 / part4;

            double part6 = number1.Imaginary * number2.Real;
            double part7 = number1.Real * number2.Imaginary;
            double part8 = part4 - part5;

            double part9 = number2.Real * number2.Real;
            double part10 = number2.Imaginary * number2.Imaginary;
            double part11 = part9 + part10;

            double part12 = part8 / part11;

            Complex number = new Complex(part5, part11);
            return number;
        }
    }
}
