﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2_4_Domotica
{
    class Toestellen
    {
        public string Kamer { get; private set; }
        public string Toestel { get; private set; }
        public int Waarde { get; private set; }

        public Toestellen(string Kam, string Toes, int Waa) // constructor
        {
            Kamer = Kam;
            Toestel = Toes;
            Waarde = Waa;

        }
        public override string ToString()
        {
            return "In de " + Kamer + " is de toestand van het apparaat (" + Toestel +"): " + Waarde + "°C.";
        }
    }
}
