﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2_4_Domotica
{
    class Lichtpunten
    {
        public string Kamer { get; private set; }
        public string Toestand { get; private set; }

        public Lichtpunten(string Kam, string Toe) // constructor
        {
            Kamer = Kam;
            Toestand = Toe;
        }
        public override string ToString()
        {
            return "In de " + Kamer + "is de toestand van het licht: " + Toestand + ".";
        }
    }
}
